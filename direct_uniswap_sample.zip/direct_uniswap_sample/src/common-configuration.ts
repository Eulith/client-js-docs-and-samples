const serverURL = "https://eth-main.eulithrpc.com";
const refreshToken: string =
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NksifQ.eyJzdWIiOiJsdWNhcyIsImV4cCI6MTcxMjA5NzMxOSwic291cmNlX2hhc2giOiIqIiwic2NvcGUiOiJBUElSZWZyZXNoIn0.e80gP2Pf-I6-iHRMMSYOMPO7iCvVAhAEkKZrv7NcOmk1x3-QldCojVGOuNCoZDSjFnV4PGio0aFKY5-w5nIX3Rs";
const Wallet1: string ="0x4d5db4107d237df6a3d58ee5f70ae63d73d7658d4026f2eefd2f204c81682cb7";

export default {
    serverURL,
    refreshToken,
    Wallet1,
};
